package uz.gita.lesson7_olimjonov_samandar18.data;

import java.io.Serializable;

public enum QuestionType implements Serializable {
    MATHEMATICS_MEDIUM,
    MATHEMATICS_EASY
}
